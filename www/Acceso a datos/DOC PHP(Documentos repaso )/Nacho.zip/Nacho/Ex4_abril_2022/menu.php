<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <title>Pedidos</title>
    <link rel="stylesheet" href="estilo.css">

  </head>
  <body>
    
   
    <h1>Gestión de PEDIDOS (NEPTUNO)</h1>
    <ul>
      <li><a href="descuento.php">Actualiza el campo descuento  de la tabla productos para ADMIN</a></li>
      <li><a href="visua.php">Visualizar Un pedido de un cliente NO ADMIN y el total del pedido</a></li>
    </ul>
    <a href="logout.php">Cerrar Sesion</a>
   
</body>
</html>
